﻿namespace GraphQLWebAPI.Infra
{
    public class UsuarioFiltro
    {
        public int? Id { get; set; }
        public string Nome { get; set; }
    }
}
